import { ReactComponent as BrandLogoExport } from './logo.svg';

export * from './ContentLogo';
export const BrandLogo = BrandLogoExport;
